# SpiralSense Chrome Extension

This folder is the functional Manifest V3 prototype for the SpiralSense hackathon project.

## Detection
The content script observes only scroll position and timing. It does not read page text, forms, images, network requests, or DOM content.

A rolling 20-second window is used. The rule requires:
- average scroll velocity above a configurable threshold
- short dwell time between scroll bursts
- the pattern sustained for the full window

A single fast swipe cannot trigger a spiral.

## Install
1. Open `chrome://extensions`.
2. Enable Developer mode.
3. Click **Load unpacked**.
4. Select this `extension` folder.
5. Open any normal `http` or `https` page and scroll.

## Permissions
`storage` is used for local settings and summaries. `http/https` host access is required because the detector runs locally on pages the user visits.

## Files
- `content.js` — detection engine and on-page intervention.
- `background.js` — local state/settings bridge.
- `popup.html/css/js` — extension popup UI.
- `manifest.json` — Manifest V3 configuration.
