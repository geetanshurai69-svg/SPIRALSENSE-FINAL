const $ = id => document.getElementById(id);

const defaults = {
  key: "normal", label: "Normal", risk: 0, velocity: 0, dwell: 0, site: ""
};

function render(data) {
  const state = { ...defaults, ...(data.state || {}) };
  $("label").textContent = state.label;
  $("velocity").innerHTML = `${Math.round(state.velocity)} <small>px/s</small>`;
  $("dwell").innerHTML = `${Math.round(state.dwell)} <small>ms</small>`;
  $("riskBar").style.width = `${Math.max(0, Math.min(100, state.risk))}%`;
  $("stateCard").style.borderColor =
    state.key === "spiral" ? "rgba(255,90,90,.45)" :
    state.key === "possible" ? "rgba(245,185,75,.45)" :
    state.key === "focused" ? "rgba(112,223,177,.35)" : "rgba(255,255,255,.09)";

  const today = data.today || {};
  $("spirals").textContent = today.spirals || 0;
  $("sessions").textContent = today.sessions || 0;
  $("focus").textContent = `${Math.floor((today.focusSeconds || 0) / 60)}m`;
  $("site").textContent = state.site || "Waiting for an active page…";

  const sensitivity = data.settings?.sensitivity ?? 60;
  $("sensitivity").value = sensitivity;
  $("sensValue").textContent = `${sensitivity}%`;
}

chrome.runtime.sendMessage({type:"GET_STATE"}, render);

$("sensitivity").addEventListener("input", e => {
  const value = Number(e.target.value);
  $("sensValue").textContent = `${value}%`;
  chrome.runtime.sendMessage({type:"SET_SENSITIVITY", value});
});

$("reset").addEventListener("click", async () => {
  const todayKey = new Date().toISOString().slice(0, 10);
  await chrome.storage.local.set({
    today: { spirals: 0, focusSeconds: 0, intentionalSeconds: 0, sessions: 0, lastDate: todayKey }
  });
  chrome.runtime.sendMessage({type:"GET_STATE"}, render);
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && (changes.currentState || changes.today || changes.settings)) {
    chrome.runtime.sendMessage({type:"GET_STATE"}, render);
  }
});
