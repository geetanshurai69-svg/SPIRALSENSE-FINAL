(() => {
  "use strict";

  const CONFIG = {
    windowMs: 20_000,
    burstGapMs: 1_200,
    sampleGapMs: 100,
    minDeltaPx: 2,
    defaultVelocity: 1_200,
    defaultDwell: 450,
    maxSamples: 240,
    cooldownMs: 120_000
  };

  let settings = {
    sensitivity: 60,
    velocityThreshold: CONFIG.defaultVelocity,
    dwellThreshold: CONFIG.defaultDwell,
    sustainWindow: 20
  };

  let samples = [];
  let lastScroll = null;
  let lastBurst = null;
  let lastState = "normal";
  let spiralShownAt = 0;
  let overlay = null;
  let breakTimer = null;

  const now = () => performance.now();

  function sensitivityFactor() {
    // Higher sensitivity makes the detector react earlier.
    return 1.35 - (settings.sensitivity / 100) * 0.7;
  }

  function thresholds() {
    const f = sensitivityFactor();
    return {
      velocity: Math.max(500, settings.velocityThreshold * f),
      dwell: Math.min(900, settings.dwellThreshold / f)
    };
  }

  function pageSite() {
    try { return location.hostname || "this page"; } catch { return "this page"; }
  }

  function addSample(velocity, dwell, t) {
    samples.push({ velocity, dwell, t });
    const cutoff = t - CONFIG.windowMs;
    samples = samples.filter(s => s.t >= cutoff).slice(-CONFIG.maxSamples);
  }

  function summarize() {
    if (!samples.length) return { velocity: 0, dwell: 0, pressure: 0, sustained: 0 };

    const velocity = samples.reduce((a, s) => a + s.velocity, 0) / samples.length;
    const dwellSamples = samples.filter(s => s.dwell > 0);
    const dwell = dwellSamples.length
      ? dwellSamples.reduce((a, s) => a + s.dwell, 0) / dwellSamples.length
      : 0;

    const { velocity: vt, dwell: dt } = thresholds();
    const matching = samples.filter(s => s.velocity >= vt && (s.dwell === 0 || s.dwell <= dt));
    const first = matching[0]?.t;
    const sustained = first ? Math.min(settings.sustainWindow, (performance.now() - first) / 1000) : 0;

    const velocityScore = Math.min(1, velocity / (vt * 1.65));
    const dwellScore = dwell === 0 ? 0.25 : Math.min(1, dt / Math.max(1, dwell));
    const sustainedScore = Math.min(1, sustained / settings.sustainWindow);

    // Require both behavioral signals. A single fast swipe cannot create a spiral.
    const pressure = Math.round(
      100 * (0.48 * velocityScore + 0.32 * dwellScore + 0.20 * sustainedScore)
    );

    return { velocity, dwell, pressure, sustained, matchingCount: matching.length };
  }

  function classify(summary) {
    const { velocity: vt, dwell: dt } = thresholds();
    const sustainedEnough = summary.sustained >= settings.sustainWindow;
    const velocityHigh = summary.velocity >= vt;
    const dwellShort = summary.dwell > 0 && summary.dwell <= dt;

    if (sustainedEnough && velocityHigh && dwellShort) return "spiral";
    if (velocityHigh && dwellShort) return "possible";
    if (summary.velocity > vt * 0.45 && summary.dwell > dt) return "focused";
    return "normal";
  }

  function statePayload(kind, summary) {
    const labels = {
      normal: "Normal",
      focused: "Focused",
      possible: "Possible spiral",
      spiral: "Spiral detected"
    };
    return {
      key: kind,
      label: labels[kind],
      risk: Math.max(0, Math.min(100, summary.pressure)),
      velocity: Math.round(summary.velocity),
      dwell: Math.round(summary.dwell),
      sustainedFor: Math.round(summary.sustained),
      site: pageSite(),
      updatedAt: Date.now()
    };
  }

  async function publish(kind, summary) {
    const state = statePayload(kind, summary);
    lastState = kind;
    await chrome.storage.local.set({ currentState: state });
    if (kind === "spiral" && Date.now() - spiralShownAt > CONFIG.cooldownMs) {
      spiralShownAt = Date.now();
      chrome.runtime.sendMessage({
        type: "SPIRAL_DETECTED",
        site: pageSite(),
        velocity: state.velocity,
        dwell: state.dwell
      }).catch(() => {});
      showOverlay(state);
    }
  }

  function showOverlay(state) {
    if (overlay) return;

    overlay = document.createElement("div");
    overlay.id = "spiralsense-overlay";
    overlay.innerHTML = `
      <div class="ss-card" role="dialog" aria-modal="false" aria-label="SpiralSense notification">
        <div class="ss-head">
          <div class="ss-icon">〰</div>
          <div>
            <div class="ss-title">You've been scrolling quickly for a while.</div>
            <div class="ss-sub">This is only a pattern notice. Nothing is wrong.</div>
          </div>
        </div>
        <div class="ss-metrics">
          <div><span>High scroll velocity</span><b>${state.velocity} px/s</b></div>
          <div><span>Very short pauses</span><b>${state.dwell} ms</b></div>
          <div><span>Pattern sustained</span><b>${state.sustainedFor}s</b></div>
        </div>
        <div class="ss-actions">
          <button id="ss-break">Take a 2-minute break</button>
          <button id="ss-continue">Keep scrolling</button>
          <button id="ss-close" aria-label="Dismiss">×</button>
        </div>
        <div class="ss-note">Computed on your device from scroll movement and timing only.</div>
      </div>`;
    document.documentElement.appendChild(overlay);

    overlay.querySelector("#ss-break").addEventListener("click", startBreak);
    overlay.querySelector("#ss-continue").addEventListener("click", dismissOverlay);
    overlay.querySelector("#ss-close").addEventListener("click", dismissOverlay);
  }

  function dismissOverlay() {
    overlay?.remove();
    overlay = null;
    lastState = "normal";
    chrome.storage.local.set({
      currentState: {
        key: "normal", label: "Normal", risk: 0, velocity: 0, dwell: 0,
        sustainedFor: 0, site: pageSite(), updatedAt: Date.now()
      }
    });
  }

  function startBreak() {
    if (!overlay) return;
    const card = overlay.querySelector(".ss-card");
    card.innerHTML = `
      <div class="ss-break">
        <div class="ss-break-title">Two-minute reset</div>
        <div class="ss-timer" id="ss-timer">2:00</div>
        <p>Take a short break. You can close this page or simply pause for a moment.</p>
        <button id="ss-end">End break</button>
      </div>`;
    let remaining = 120;
    const tick = () => {
      const el = card.querySelector("#ss-timer");
      if (!el) return;
      el.textContent = `${Math.floor(remaining / 60)}:${String(remaining % 60).padStart(2, "0")}`;
      if (remaining <= 0) {
        clearInterval(breakTimer);
        el.textContent = "Done";
      }
      remaining -= 1;
    };
    tick();
    clearInterval(breakTimer);
    breakTimer = setInterval(tick, 1000);
    card.querySelector("#ss-end").addEventListener("click", () => {
      clearInterval(breakTimer);
      dismissOverlay();
    });
  }

  function onScroll() {
    const t = now();
    const y = window.scrollY;
    if (!lastScroll) {
      lastScroll = { y, t };
      lastBurst = t;
      return;
    }

    const dt = t - lastScroll.t;
    const dy = Math.abs(y - lastScroll.y);
    lastScroll = { y, t };

    if (dt < 1 || dy < CONFIG.minDeltaPx) return;

    // Ignore one-off huge programmatic jumps.
    const velocity = Math.min(10_000, (dy / dt) * 1000);
    // Dwell is the time since the previous scroll event. Fast repeated
    // scrolling creates short gaps; reading creates longer gaps.
    const dwell = Math.min(5_000, Math.max(0, dt));
    lastBurst = t;

    addSample(velocity, dwell, t);

    // Throttle state computation to roughly 10 Hz.
    if (dt >= CONFIG.sampleGapMs || samples.length === 1) {
      const summary = summarize();
      const kind = classify(summary);
      if (kind !== lastState || kind === "spiral") publish(kind, summary);
    }
  }

  function loadSettings() {
    chrome.storage.local.get("settings").then(data => {
      if (data.settings) settings = { ...settings, ...data.settings };
    });
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes.settings?.newValue) {
      settings = { ...settings, ...changes.settings.newValue };
    }
  });

  const style = document.createElement("style");
  style.textContent = `#spiralsense-overlay {
  all: initial;
  position: fixed !important;
  inset: 0 !important;
  z-index: 2147483647 !important;
  display: flex !important;
  align-items: center !important;
  justify-content: center !important;
  padding: 16px !important;
  background: rgba(11, 10, 18, .72) !important;
  backdrop-filter: blur(10px) !important;
  font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif !important;
}
#spiralsense-overlay * { box-sizing: border-box !important; }
#spiralsense-overlay .ss-card {
  width: min(420px, calc(100vw - 32px)) !important;
  padding: 24px !important;
  border: 1px solid rgba(255,255,255,.11) !important;
  border-radius: 24px !important;
  background: linear-gradient(180deg, rgba(40,38,51,.97), rgba(24,23,34,.98)) !important;
  color: #fff !important;
  box-shadow: 0 24px 60px rgba(0,0,0,.45) !important;
}
#spiralsense-overlay .ss-head { display:flex !important; gap:12px !important; align-items:flex-start !important; }
#spiralsense-overlay .ss-icon {
  width:40px !important; height:40px !important; flex:0 0 40px !important;
  display:grid !important; place-items:center !important; border-radius:14px !important;
  background: linear-gradient(135deg,#7958ff,#b64cff) !important; font-size:22px !important;
}
#spiralsense-overlay .ss-title { font-size:18px !important; font-weight:650 !important; line-height:1.25 !important; }
#spiralsense-overlay .ss-sub, #spiralsense-overlay .ss-note {
  margin-top:4px !important; color:#aaa6b8 !important; font-size:13px !important; line-height:1.45 !important;
}
#spiralsense-overlay .ss-metrics { margin-top:18px !important; display:grid !important; gap:8px !important; }
#spiralsense-overlay .ss-metrics div {
  display:flex !important; justify-content:space-between !important; gap:12px !important;
  padding:10px 12px !important; border-radius:12px !important; background:rgba(255,255,255,.055) !important;
  font-size:13px !important;
}
#spiralsense-overlay .ss-metrics span { color:#aaa6b8 !important; }
#spiralsense-overlay .ss-actions { display:flex !important; gap:8px !important; margin-top:20px !important; }
#spiralsense-overlay button {
  appearance:none !important; border:0 !important; border-radius:12px !important; min-height:44px !important;
  padding:0 14px !important; font:600 13px Inter, system-ui, sans-serif !important; cursor:pointer !important;
}
#spiralsense-overlay #ss-break { flex:1 !important; color:#fff !important; background:linear-gradient(135deg,#7958ff,#b64cff) !important; }
#spiralsense-overlay #ss-continue { flex:1 !important; color:#fff !important; background:#353342 !important; }
#spiralsense-overlay #ss-close { width:44px !important; padding:0 !important; color:#aaa6b8 !important; background:transparent !important; font-size:22px !important; }
#spiralsense-overlay .ss-break { text-align:center !important; }
#spiralsense-overlay .ss-break-title { font-size:20px !important; font-weight:650 !important; }
#spiralsense-overlay .ss-timer { margin:20px 0 8px !important; font:700 56px/1 ui-monospace, SFMono-Regular, Menlo, monospace !important; }
#spiralsense-overlay .ss-break p { color:#aaa6b8 !important; font-size:13px !important; line-height:1.5 !important; }
#spiralsense-overlay #ss-end { margin-top:14px !important; color:#fff !important; background:#353342 !important; width:100% !important; }`;
  document.documentElement.appendChild(style);

  loadSettings();
  window.addEventListener("scroll", onScroll, { passive: true });
})();