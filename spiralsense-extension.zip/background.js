const DEFAULTS = {
  settings: {
    sensitivity: 60,
    velocityThreshold: 1200,
    dwellThreshold: 450,
    sustainWindow: 20
  },
  today: {
    spirals: 0,
    focusSeconds: 0,
    intentionalSeconds: 0,
    sessions: 0,
    lastDate: new Date().toISOString().slice(0, 10)
  }
};

async function getData() {
  const data = await chrome.storage.local.get(["settings", "today"]);
  const todayKey = new Date().toISOString().slice(0, 10);
  const today = data.today && data.today.lastDate === todayKey
    ? data.today
    : { ...DEFAULTS.today, lastDate: todayKey };
  const settings = { ...DEFAULTS.settings, ...(data.settings || {}) };
  await chrome.storage.local.set({ settings, today });
  return { settings, today };
}

chrome.runtime.onInstalled.addListener(() => getData());

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "GET_STATE") {
    chrome.storage.local.get(["currentState", "settings", "today"]).then(async data => {
      const base = await getData();
      sendResponse({
        state: data.currentState || {
          label: "Normal",
          risk: 0,
          velocity: 0,
          dwell: 0,
          site: sender?.tab?.url || "",
          updatedAt: Date.now()
        },
        settings: base.settings,
        today: base.today
      });
    });
    return true;
  }

  if (message?.type === "SET_SENSITIVITY") {
    getData().then(({ settings }) => {
      const sensitivity = Math.max(10, Math.min(100, Number(message.value) || 60));
      const next = { ...settings, sensitivity };
      chrome.storage.local.set({ settings: next }).then(() => sendResponse({ ok: true, settings: next }));
    });
    return true;
  }

  if (message?.type === "SPIRAL_DETECTED") {
    getData().then(({ today }) => {
      const nextToday = {
        ...today,
        spirals: (today.spirals || 0) + 1,
        sessions: (today.sessions || 0) + 1
      };
      chrome.storage.local.set({
        today: nextToday,
        lastSpiral: {
          site: message.site || "unknown",
          at: Date.now(),
          velocity: message.velocity,
          dwell: message.dwell
        }
      }).then(() => sendResponse({ ok: true }));
    });
    return true;
  }
});
